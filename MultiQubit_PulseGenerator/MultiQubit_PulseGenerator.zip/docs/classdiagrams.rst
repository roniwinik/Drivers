Class diagrams
==============

.. inheritance-diagram:: gates
  :top-classes: gates.BaseGate
