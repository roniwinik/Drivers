.. Multi Qubit Pulse Generator documentation master file, created by
   sphinx-quickstart on Thu May 24 11:36:09 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Multi Qubit Pulse Generator's documentation!
=======================================================

.. toctree::
  :maxdepth: 2
  :numbered:

  classdiagrams
  summary
